
var myLink=document.getElementById("btns");
window.onload =function(){
myLink.onclick=function(){
    alert("Check your mail");
}
}