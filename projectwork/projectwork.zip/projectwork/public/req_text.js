var myText=document.getElementById('btns');
myText.onclick=function(){
    alert('done');
}