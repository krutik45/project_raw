var myLink=document.getElementById("btns");
myLink.onclick=function(){
    alert("Check your mail");
}